package com.pasfinal.Adaptadores.Apresentacao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.http.ResponseEntity;

import com.pasfinal.Adaptadores.Apresentacao.Presenters.CabecalhoCardapioPresenter;
import com.pasfinal.Adaptadores.Apresentacao.Presenters.CardapioPresenter;
import com.pasfinal.Aplicacao.RecuperaListaCardapiosUC;
import com.pasfinal.Aplicacao.RecuperarCardapioUC;
import com.pasfinal.Aplicacao.Responses.CardapioResponse;
import org.springframework.beans.factory.annotation.Value;
import com.pasfinal.Dominio.Entidades.Produto;

@RestController
@RequestMapping("/cardapio")
public class CardapioController {
    private RecuperarCardapioUC recuperaCardapioUC;
    private RecuperaListaCardapiosUC recuperaListaCardapioUC;
    @Value("${application.currentCardapioId}")
    private long currentCardapioId;

    public CardapioController(RecuperarCardapioUC recuperaCardapioUC,
                              RecuperaListaCardapiosUC recuperaListaCardapioUC) {
        this.recuperaCardapioUC = recuperaCardapioUC;
        this.recuperaListaCardapioUC = recuperaListaCardapioUC;
    }

    /**
     * Recupera cardápio por ID
     * 
     * Headers enviados pelo Gateway (após validação JWT):
     * - X-User-Email: email do usuário autenticado
     * - X-User-Type: tipo do usuário (USUARIO ou ADMIN)
     * - X-User-CPF: CPF do cliente
     * 
     * Se a requisição chegou até aqui, o Gateway já validou a autenticação.
     */
    @GetMapping("/{id}")
    @CrossOrigin("*")
    public ResponseEntity<?> recuperaCardapio(
            @PathVariable(value="id") long id,
            @RequestHeader(value = "X-User-Email", required = false) String userEmail){
        
        // Se o header não existe, significa que passou direto sem o Gateway
        // (útil para testes locais ou endpoints públicos futuros)
        if (userEmail == null) {
            userEmail = "anonymous";
        }
        
        CardapioResponse cardapioResponse = recuperaCardapioUC.run(id);
        Set<Long> conjIdSugestoes = new HashSet<>(cardapioResponse.getSugestoesDoChef().stream()
            .map(produto->produto.getId())
            .toList());
        CardapioPresenter cardapioPresenter = new CardapioPresenter(cardapioResponse.getCardapio().getTitulo());
        for(Produto produto:cardapioResponse.getCardapio().getProdutos()){
            boolean sugestao = conjIdSugestoes.contains(produto.getId());
            cardapioPresenter.insereItem(produto.getId(), produto.getDescricao(), produto.getPreco(), sugestao);
        }
        return ResponseEntity.ok(cardapioPresenter);
    }

    @GetMapping("/lista")
    @CrossOrigin("*")
    public List<CabecalhoCardapioPresenter> recuperaListaCardapios(){
         List<CabecalhoCardapioPresenter> lstCardapios = 
            recuperaListaCardapioUC.run().cabecalhos().stream()
            .map(cabCar -> new CabecalhoCardapioPresenter(cabCar.id(),cabCar.titulo()))
            .toList();
         return lstCardapios;
    }
    
    /**
     * Recupera o cardápio atual (configurado em application.yaml)
     */
    @GetMapping
    @CrossOrigin("*")
    public ResponseEntity<?> recuperaCardapioAtual(
            @RequestHeader(value = "X-User-Email", required = false) String userEmail) {
        
        return recuperaCardapio(currentCardapioId, userEmail);
    }
}
